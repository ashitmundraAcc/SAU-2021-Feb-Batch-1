import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ViewTimesheetComponent } from './view-timesheet/view-timesheet.component';
const routes: Routes = [
  {
    path: '',
    component: ViewTimesheetComponent,
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
