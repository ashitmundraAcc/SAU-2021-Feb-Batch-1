import { Injectable } from '@angular/core';
import { Cdetails } from './modal/lecture';

@Injectable({
    providedIn: 'root'
})

export class TimesheetService{
    id: number;
    tsheet: Cdetails;
    timesheet: Cdetails[] = [
        {
            name: 'demo',
            instructor: 'demoInstructor',
            desc:'It is a demo object dont expect any valuable description. Added all add Delete and Edit functionalities in the app.'

        }
    ]


    constructor() { }

    getTimesheet(){
        return this.timesheet;
    }

    deleteTimesheet(x) {
        this.timesheet.splice(x, 1);
    }

    addTimesheet(x: Cdetails) {
        this.timesheet.push(x);
    }

    updateTimesheet(x, lec: Cdetails){
        this.timesheet[x]=lec;

    }
}