import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup} from '@angular/forms';
import { Cdetails } from '../modal/lecture';
import { TimesheetService } from '../timesheet.service';
import { MatDialogRef } from '@angular/material/dialog';
import { ViewTimesheetComponent } from '../view-timesheet/view-timesheet.component';
@Component({
  selector: 'app-add-timesheet',
  templateUrl: './add-timesheet.component.html',
  styleUrls: ['./add-timesheet.component.scss']
})
export class AddTimesheetComponent implements OnInit {

  lecform: FormGroup;
  constructor(private timesheetService: TimesheetService, private dialogRef: MatDialogRef<ViewTimesheetComponent>) { }

  ngOnInit(): void {
    this.lecform = new FormGroup({
      name: new FormControl(""),
      instructor: new FormControl(""),
      desc: new FormControl("")
    });
  }

  get name() {
    return this.lecform.get('name') as FormControl;
  }

  get instructor() {
    return this.lecform.get('instructor') as FormControl;
  }

  get desc() {
    return this.lecform.get('desc') as FormControl;
  }

  addLecture(){
    const timesh: Cdetails = {
      name: this.name.value,
      instructor: this.instructor.value,
      desc: this.desc.value,
    }
    this.timesheetService.addTimesheet(timesh);
    this.dialogRef.close();
  }

}
