export interface Cdetails {
    name: String;
    instructor: String;
    desc: String;
}