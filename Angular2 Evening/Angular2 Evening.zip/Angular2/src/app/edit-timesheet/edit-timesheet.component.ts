import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup} from '@angular/forms';
import { Cdetails } from '../modal/lecture';
import { TimesheetService } from '../timesheet.service';
import { MatDialogRef } from '@angular/material/dialog';
import { ViewTimesheetComponent } from '../view-timesheet/view-timesheet.component';
@Component({
  selector: 'app-edit-timesheet',
  templateUrl: './edit-timesheet.component.html',
  styleUrls: ['./edit-timesheet.component.scss']
})
export class EditTimesheetComponent implements OnInit {
  lecform: FormGroup;
  constructor(private timesheetService: TimesheetService, private dialogRef: MatDialogRef<ViewTimesheetComponent>) { }

  ngOnInit(): void {
    this.lecform = new FormGroup({
      name: new FormControl(this.timesheetService.tsheet.name),
      instructor: new FormControl(this.timesheetService.tsheet.instructor),
      desc: new FormControl(this.timesheetService.tsheet.desc)
    });
  }

  get name() {
    return this.lecform.get('name') as FormControl;
  }

  get instructor() {
    return this.lecform.get('instructor') as FormControl;
  }

  get desc() {
    return this.lecform.get('desc') as FormControl;
  }

  editLec() {
    const timesh: Cdetails = {
      name: this.name.value,
      instructor: this.instructor.value,
      desc: this.desc.value,
    }
    this.timesheetService.updateTimesheet(this.timesheetService.id, timesh);
    this.dialogRef.close();
  }
}
