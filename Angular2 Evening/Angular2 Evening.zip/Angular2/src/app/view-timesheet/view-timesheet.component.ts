import { Component, OnInit } from '@angular/core';
import { Cdetails } from '../modal/lecture';
import { TimesheetService } from '../timesheet.service';
import { AddTimesheetComponent } from '../add-timesheet/add-timesheet.component';
import { MatDialog } from '@angular/material/dialog';
import { EditTimesheetComponent } from '../edit-timesheet/edit-timesheet.component';
@Component({
  selector: 'app-view-timesheet',
  templateUrl: './view-timesheet.component.html',
  styleUrls: ['./view-timesheet.component.scss']
})
export class ViewTimesheetComponent implements OnInit {

  timesheetItems: Cdetails[]= []
  
  constructor(private timesheetService: TimesheetService, private box: MatDialog) { }

  ngOnInit(): void {
    this.timesheetItems= this.timesheetService.getTimesheet();
  }

  addLec(){
    this.box.open(AddTimesheetComponent);
  }

  delLec(x){
    this.timesheetService.deleteTimesheet(x);
  }

  updateLec(x){
    this.timesheetService.id=x;
    this.timesheetService.tsheet=this.timesheetItems[x];

    this.box.open(EditTimesheetComponent);
  }

}
