package com.au.assign1;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.List;
import java.util.Scanner;

public class Menu
{
    static Scanner sc = new Scanner(System.in);

    public static void selectchoice()
    {
        System.out.println("1 for Creating Employee\n");
        System.out.println("2 for Updating  Employee\n");
        System.out.println("3 for Deleting Employee\n");
        System.out.println("4 for Getting all Employees Details\n");
        System.out.println("5 for Get Employee Details by ID\n");
        System.out.println("6 to Exit\n");
        System.out.println("Enter choice\n");
    }

    public static Employee addEmployee()
    {
        Employee emp =new Employee();

        System.out.println("FName");
        emp.setFname(sc.next());

        System.out.println("LName");
        emp.setLname(sc.next());

        System.out.println("Age");
        int age = sc.nextInt();

        do
        {
            emp.setAge(age);
            if(age < 10)
            {
                System.out.println("Enter 2 digits");
                age = sc.nextInt();
            }
        }while (age < 10);

        System.out.println("Salary");
        emp.setSalary(sc.nextInt());

        System.out.println("DOB");
        emp.setDob(sc.next());

        System.out.println("Designation");
        emp.setDesignation(sc.next());

        return emp;
    }

    public static void main(String[] args)
    {
        int x = 0;
        do
        {
            Configuration configuration = new Configuration().configure().addAnnotatedClass(Employee.class);
            SessionFactory factory = configuration.buildSessionFactory();
            Session session = factory.openSession();
            Transaction t = session.beginTransaction();


            selectchoice();
            x = sc.nextInt();

            switch (x)
            {
                case 1:
                    Employee employ = addEmployee();
                    session.save(employ);
                    t.commit();
                    System.out.println("Added Employee\n");
                    break;

                case 2:
                    System.out.println("\n");
                    try
                    {
                        System.out.println("Enter ID");
                        int id = sc.nextInt();

                        System.out.println("Field to update \n 1 for Fname\n 2 for Lname\n 3 for Age\n 4 for Salary\n 5 for DOB\n 6 for Designation\n");
                        int k = sc.nextInt();

                        Employee upemploy = (Employee) session.get(Employee.class, id);
                        switch(k)
                        {
                            case 1:
                                System.out.println("Fname\n");
                                String fname = sc.next();
                                upemploy.setFname(fname);
                                System.out.println("Updated");
                                t.commit();
                                break;

                            case 2:
                                System.out.println("Lname\n");
                                String lname = sc.next();
                                upemploy.setLname(lname);
                                System.out.println("Updated");
                                t.commit();
                                break;

                            case 3:
                                System.out.println("Age\n");
                                int newage = sc.nextInt();
                                upemploy.setAge(newage);
                                System.out.println("Updated");
                                t.commit();
                                break;

                            case 4:
                                System.out.println("Salary\n");
                                int newsal = sc.nextInt();
                                upemploy.setSalary(newsal);
                                System.out.println("Updated");
                                t.commit();
                                break;

                            case 5:
                                System.out.println("DOB\n");
                                String newdob = sc.next();
                                upemploy.setDob(newdob);
                                System.out.println("Updated");
                                t.commit();
                                break;

                            case 6:
                                System.out.println("Designation\n");
                                String newdes = sc.next();
                                upemploy.setDesignation(newdes);
                                System.out.println("Updated");
                                t.commit();
                                break;

                            default:
                                System.out.println("Error");
                                break;
                        }
                    }
                    catch(Exception e)
                    {
                        System.out.println("ID not found");
                    }
                    break;

                case 3:
                    System.out.println("\n");
                    try
                    {
                        System.out.println("Enter ID");
                        int id = sc.nextInt();
                        System.out.println("Confirm?");
                        char c = sc.next().charAt(0);
                        if(c=='Y' || c == 'y')
                        {
                            Employee delEmp = (Employee) session.load(Employee.class, id);
                            session.delete(delEmp);
                            System.out.println("Deleted");
                            t.commit();

                        }
                        else if(c=='N')
                        {
                            System.out.println("No operations");
                            break;
                        }
                    }
                    catch(Exception e)
                    {
                        System.out.println("Invalid employee");
                    }
                    break;

                case 4:
                    System.out.println("\n");
                    Query query = session.createQuery("from Employee");
                    List<Employee> emp =  query.list();
                    System.out.println("Employee details");
                    for(Employee e : emp) {
                        System.out.println(e.toString());
                    }
                    t.commit();
                    break;
                    
                case 5:
                    System.out.println("\n");
                    System.out.println("Enter ID");
                    int id = sc.nextInt();
                    System.out.println("Employee Detail");
                    Employee empp = (Employee) session.get(Employee.class, id);
                    if(empp != null)
                        System.out.println(empp.toString());
                    else
                        System.out.println("Invalid employee\n");
                    t.commit();
                    break;

                case 6:
                	session.close();
                	factory.close();
                    break;

                default:
                    System.out.println("Error");
                    continue;

            }


        }while (x != 6);

        sc.close();
    }
}
