package com.au.a2hib;

import java.util.Scanner;
import org.hibernate.Session;  
import org.hibernate.SessionFactory;  
import org.hibernate.Transaction;  
import org.hibernate.cfg.Configuration;

import com.au.a2hib.Category;
import com.au.a2hib.Product;
import com.au.a2hib.Supplier;

public class App 
{
	static Scanner s = new Scanner(System.in);
	static SessionFactory sessionfactory =  new Configuration().configure()
	.addAnnotatedClass(Product.class)
	.addAnnotatedClass(Supplier.class)
	.addAnnotatedClass(Category.class)
	.buildSessionFactory();

	public static void main(String[] args) {
		{
			Product p1 = new Product(1, "P1");
			Product p2 = new Product(2, "P2");
			Product p3 = new Product(3, "P3");
			Product p4 = new Product(4, "P4");
			Product p5 = new Product(5, "P5");
			
			Supplier s1 = new Supplier(1, "S1");
			Supplier s2 = new Supplier(2, "S2");
			Supplier s3 = new Supplier(3, "S3");
			Supplier s4 = new Supplier(4, "S4");
			Supplier s5 = new Supplier(5, "S5");
			
			
			Category c1 = new Category(1, "C1");
			Category c2 = new Category(2, "C2");
			Category c3 = new Category(3, "C3");
			Category c4 = new Category(4, "C4");
			Category c5 = new Category(5, "C5");
			Category c6 = new Category(6, "C6");
			Category c7 = new Category(7, "C7");
			Category c8 = new Category(8, "C8");
			
			
			p1.setCategory(c1);p2.setCategory(c6);
			p3.setCategory(c8);p4.setCategory(c7);
			p5.setCategory(c4);
	
			
			c1.addProduct(p1);c3.addProduct(p2);
			c8.addProduct(p3);c7.addProduct(p4);
			c3.addProduct(p5);
			
			
			s1.addCategory(c1);s1.addCategory(c8);
			s2.addCategory(c2);s2.addCategory(c3);
			s4.addCategory(c6);s3.addCategory(c7);
			s2.addCategory(c7);s4.addCategory(c1);
			s5.addCategory(c7);s5.addCategory(c3);
			
			c1.addSupplier(s1);c2.addSupplier(s2);c3.addSupplier(s3);
			c4.addSupplier(s4);c5.addSupplier(s5);c6.addSupplier(s3);
			c7.addSupplier(s4);c8.addSupplier(s1);
			
			
			Session session = sessionfactory.openSession();
			Transaction t = session.beginTransaction();
			
			session.save(p1);session.save(p2);session.save(p3);session.save(p4);session.save(p5);
			session.save(s1);session.save(s2);session.save(s3);session.save(s4);session.save(s5);
			session.save(c1);session.save(c2);session.save(c3);session.save(c4);session.save(c5);
			session.save(c6);session.save(c7);session.save(c8);
	
			t.commit();
			session.close();
		}
	}
}
