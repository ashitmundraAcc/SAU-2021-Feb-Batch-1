import './App.css';
import {BookHomePage} from "./components/homepage";
import {Switch,BrowserRouter as Router,Route} from "react-router-dom";
import {BookReadSection} from "./components/bookData";
import {getBook} from "./service";

function App() {

  const mapId = (data) =>{
      const id = data.match.params.mappedId;
      return (
          <BookReadSection book={getBook().filter((x)=> x.id === id)[0]}/>
      )
  }

  return (
    <div>
        <div className="header">
                <h1>Accolite Books </h1>
        </div>
        <Router>
            <Switch>
                <Route path={'/'} component={BookHomePage} exact></Route>
                <Route path={'/:mappedId'} component={mapId}></Route>
            </Switch>
        </Router>
    </div>
  );
}

export default App;
