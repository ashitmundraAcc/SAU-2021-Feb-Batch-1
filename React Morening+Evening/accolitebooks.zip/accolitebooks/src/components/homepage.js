import {Link} from 'react-router-dom';
import React, {useState} from 'react';
import {getBook} from "../service";
import {SearchBook} from "./searchBook";
import "../App.css";

export function BookHomePage(){
    const [sbook, setSbook] = useState('%%%');
    const [books] = useState(getBook());

    const MainBook = () =>
    {
        return books.map((book) =>
        {
            return(
                <div key = {book.id}>
                    <ul class="tilesWrap">
                    <Link to={`/${book.id}`}>
                        <li>
                            <h2>{book.id}</h2>
                            <h3>{book.name}</h3>
                            <p>Writer: {book.writer}</p>
                            <button>Read more</button>
                        </li>
                    </Link>
                    </ul>
                </div>
            )
    })
};
const searchfunc = () =>
{
    return books.filter((book) => book.name.toLowerCase().includes(sbook.toLowerCase()));
}

const setItem = (wbook) =>
{
    if(wbook.target.value !== '')
        setSbook(wbook.target.value)
    else
        setSbook('%%%')
}

return(
    <div>
        <br></br>
        <div>
            <input className="inp" onChange={setItem}  placeholder={'Search here'}/>
            <SearchBook  books= {searchfunc()} />
        </div>
        <MainBook />
    </div>
)
}


