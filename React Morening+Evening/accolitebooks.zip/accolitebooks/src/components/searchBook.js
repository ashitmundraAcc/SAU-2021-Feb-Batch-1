import {Link} from "react-router-dom";
import "../App.css"
export const SearchBook = ({books}) =>
{
    const temp =  (books.map((book) => {
      return (
         <div className="setS">
             <Link to={`/${book.id}`} >
                 <button className="styleButton">
                    {book.name}
                </button>
             </Link>
        </div>
      )
    }))
    return (
        <div>
            {temp}
        </div>
    )
}