import "../App.css"
export const BookReadSection = ({book}) =>
{
    return(
	    <div key={book.id} className="overlay">
            <h1>{book.name}</h1>
            <h3>{book.writer}</h3>
            <p>{book.about}</p>
		</div>
    )
}