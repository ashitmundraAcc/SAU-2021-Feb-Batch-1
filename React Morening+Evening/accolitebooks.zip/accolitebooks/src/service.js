let bookdata =[
    {
        id : "1",
        name : "1984",
        writer : "George Orwell",
        about : "1984 tells the futuristic story of a dystopian, totalitarian world where free will and love are forbidden. Although the year 1984 has long since passed, the prophecy of a society controlled by fear and lies is arguably more relevant now than ever."
    },
    {
        id : "2",
        name : "The Lord of the Rings",
        writer : "J.R.R. Tolkien",
        about : "Tolkien’s fantasy epic is one of the top must-read books out there. Set in Middle Earth – a world full of hobbits, elves, orcs, goblins, and wizards – The Lord of the Rings will take you on an unbelievable adventure."
    },
    {
        id : "3",
        name : "The Kite Runner",
        writer : "Khaled Hosseini",
        about : "The Kite Runner is a moving story of an unlikely friendship between a wealthy boy and the son of his father’s servant. Set in Afghanistan during a time of tragedy and destruction, this unforgettable novel will have you hooked from start to finish."
    },
    {
        id : "4",
        name : "Harry Potter and the Philosopher’s Stone",
        writer : "J.K. Rowling",
        about : "This global bestseller took the world by storm. So, if you haven’t read J.K. Rowling’s Harry Potter, now may be the time. Join Harry Potter and his schoolmates as this must-read book transports you deep into a world of magic and monsters."
    },
    {
        id : "5",
        name : "Slaughterhouse-Five",
        writer : "Kurt Vonnegut",
        about : "Slaughterhouse-Five is arguably one of the greatest anti-war books ever written. This rich and amusing tale follows the life of Billy Pilgrim as he experiences World War II from a peculiar perspective."
    },
    {
        id : "6",
        name : "To Kill a Mockingbird",
        writer : "Harper Lee",
        about : "To Kill a Mockingbird is one of the top must-read books of all time. Published in 1960, the story explores life in the Deep South during the early 20th century through the story of a man accused of a terrible crime. It’s poignant, humorous, and gripping."
    },
    {
        id : "7",
        name : "Wuthering Heights",
        writer : "Emily Bronte",
        about : "Wuthering Heights is a classic novel published way back in 1847. This harrowing story, set on a lonely English moorland, follows Catherine Earnshaw and Heathcliff’s struggle with love, betrayal, and revenge."
    },
]

export const getBook = () =>
{
    return bookdata;
}