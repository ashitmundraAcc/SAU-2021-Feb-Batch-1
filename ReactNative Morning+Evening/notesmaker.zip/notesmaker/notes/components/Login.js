import React, { useEffect, useState } from 'react';
import {StyleSheet, Text, TextInput, TouchableOpacity, View, AsyncStorage } from 'react-native';

export default function Login({navigation})
{
    const [username,setUsername]=useState("")
    const [msg,setMsg]=useState("")

    useEffect(()=>{
        Auth();
    },[])

    async function Auth()
    {
        let username=await AsyncStorage.getItem("username");
        if(username)
            {
                navigation.navigate("Dashboard")
                
            }
    }

    function enter()
    {
        if(!username)
        {
            setMsg("Empty Field");
        }
        else{
            setMsg("");
            AsyncStorage.setItem("username",username);
            navigation.navigate("Dashboard");

        }
    }

    return(
    <View style={styles.main}>
        <TextInput placeholder="username" style={styles.loginput} onChangeText={(data)=>setUsername(data)}/>
        <TouchableOpacity onPress={enter}>
            <Text style={styles.logbutton}>Login</Text>
        </TouchableOpacity>
        <Text style={styles.msg}>{msg}</Text>
    </View>
    )
}

const styles=StyleSheet.create({
    main:{
        flex:1,
        backgroundColor: "#000000",
        alignItems:"center",
        justifyContent:"center",
    },

    loginput:{
        borderStyle:"solid",
        borderWidth:1,
        borderColor:"#7a42f4",
        backgroundColor:"#FFFFFF",
        width:180,
        borderRadius:3,
        textAlign:"center",
        fontSize:18,
        fontWeight:"300",
        padding:10,
        color:"white"
    },
    logbutton:
    {
        width:80,
        backgroundColor:"#FF5333",
        color:"#FFFFFF",
        textAlign:"center",
        fontSize:10,
        padding:10,
        marginTop:20,
        borderRadius:10
    },
    msg:{
        color:"white",
        fontSize:15,
        marginTop:20        
    }
})



