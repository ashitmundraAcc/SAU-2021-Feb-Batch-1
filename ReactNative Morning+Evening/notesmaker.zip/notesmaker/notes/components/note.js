import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';

export default function Note(props)
{

    function deletenote()
    {
        props.deletenote(props.id);
    }
    return(
        <View style={styles.main}>
        <View style={styles.container}>
            <Text style={styles.title}>{props.title}</Text>
            <Text style={styles.desc}>{props.desc}</Text>
            <TouchableOpacity onPress={deletenote}>
                <Text style={styles.delete}>Remove</Text>
            </TouchableOpacity>
        </View>
        </View>
    )
}

const styles=StyleSheet.create({
    main:{
        alignItems:"center",
        backgroundColor: "#000000",
    },

    container:{
        width:"80%",
        alignItems:"center",
        marginTop:20,
        margin:15,
        backgroundColor:"#09FBE6",
        borderRadius: 20
    },
    title:{
        fontSize:20,
        color:"white",
        padding:10,
    },
    desc:{
        color:"white",
        padding:5,
        fontSize:15
    },
    delete:{
        backgroundColor:"#FF336A",
        color:"#FFFFFF",
        padding:2,
        margin:2,
        borderRadius:10,
        marginVertical: 10,
        textAlign:"center",
        width:60,
        height:25
    }
})