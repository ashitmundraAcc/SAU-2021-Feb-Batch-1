import React, { useEffect } from "react";
import {Text,StyleSheet,ScrollView,TouchableOpacity} from "react-native";
import { useState } from "react/cjs/react.development";
import Note from "./note";

var allNotes = [
  {
    title: "Demo1",
    desc: "This is a demo note",
  }
];

export default function Dashboard({ navigation, route }) {
  const { ntitle="", ndesc="" } = route.params || {}
  const [notes, setNote] = useState(allNotes);

  var newNote = {
    title: ntitle,
    desc: ndesc,
  };

  function addnotetolist() {
    if(ntitle){
      setNote((prevNotes) => {
        return [newNote, ...prevNotes];
      });
     
    }
  }

  useEffect(() => {
    addnotetolist();
  }, [route.params]);

  var noteslist = notes.map((note, index) => (
    <Note
      title={note.title}
      desc={note.desc}
      key={index}
      deletenote={deletenote}
      id={index}
    />
  ));

  function deletenote(id) {
    setNote((prevNotes) => {
      return prevNotes.filter((noteItem, index) => {
        return index !== id;
      });
    });
  }

  function addnote() {
    navigation.navigate("AddNote");
  }
  return (
    <ScrollView style={styles.container}>
      <TouchableOpacity onPress={addnote}>
        <Text style={styles.addnote}>New</Text>
      </TouchableOpacity>
      {notes.length!=0?noteslist:<Text style={styles.empty}>Empty</Text>}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#000000"
  },

  addnote: {
    textAlign: "center",
    backgroundColor: "#2FC245",
    color: "white",
    padding: 10,
    marginBottom: 40,
    marginTop: 20,
    fontSize: 15,
    width: "40%",
    borderRadius: 15,
    alignSelf: "center",
  },
  empty:{
    textAlign:"center",
    color:"#50a3a2",
    fontSize:20,
    padding:10,
  }
});
