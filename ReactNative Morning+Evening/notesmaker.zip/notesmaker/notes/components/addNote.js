import React from 'react'
import { View,Text, StyleSheet } from 'react-native'
import { TextInput, TouchableOpacity } from 'react-native-gesture-handler'
import { useState } from 'react/cjs/react.development'

export default function addNote({navigation})
{
    const [title,settitle]=useState("");
    const [desc,setdesc]=useState("");

    function adder()
    {
        navigation.navigate("Dashboard",{
           ntitle:title,
           ndesc:desc
        })
    }

    return(
    <View style={styles.main}>
        <Text style={styles.header}>New Note</Text>
        <TextInput placeholder="Title" style={styles.input1} onChangeText={(data)=>settitle(data)} />
        <TextInput placeholder="Description" style={styles.input2} onChangeText={(data)=>setdesc(data)} />
        <TouchableOpacity onPress={adder}>
            <Text style={styles.addbutton}>Add</Text>
        </TouchableOpacity>
    </View>
    );
}

const styles=StyleSheet.create({
    main:{
        flex:1,
        backgroundColor: "#000000",
        alignItems:"center",
    },
    header:{
        fontSize:30,
        color:"white",
        marginVertical:40,
        marginBottom: 60
    },
    input1:{
        margin: 15,
        height: 40,
        width: 200,
        borderColor: '#7a42f4',
        borderWidth: 1,
        color: "#FFFFFF",
        textAlign: 'center',
        borderRadius:20

    },
    input2:{
        margin: 15,
        height: 200,
        width: 200,
        borderColor: '#7a42f4',
        borderWidth: 1,
        color: "#FFFFFF",
        textAlign: 'center',
        borderRadius:20

    },
    addbutton:{
        width:100,
        backgroundColor:"#FF5333",
        color:"#FFFFFF",
        textAlign:"center",
        fontSize:15,
        padding:10,
        marginTop:15,
        borderRadius:5
    }
})