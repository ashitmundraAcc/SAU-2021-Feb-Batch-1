package com.sau.service;


import com.sau.model.Movie;
import com.sau.model.Series;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ShapeService {

	@Autowired
	private Movie movie;

	@Autowired
	private Series series;
	
	public Series getSeries() {
        System.out.println("its getSeries");
		return series;
	}

	public void setSeries(Series series) {
        System.out.println("its setSeries");
		this.series = series;
	}

	public Movie getMovie() {
        System.out.println("its getMovie");
		return movie;
	}

	public void setMovie(Movie movie) {

        System.out.println("its setMovie");
		this.movie = movie;
	}

	
}
