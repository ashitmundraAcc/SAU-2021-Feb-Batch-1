package com.sau.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {

	@After("execution(* get*())")
	public void Aftergetting() {
		System.out.println("After getting called");
	}

	@AfterReturning("args(name)")
	public void AfterReturning(String name) {
		System.out.println("After Returning returns " + name);
	}

	@AfterThrowing(pointcut = "args(name)", throwing = "excep")
	public void throwingException(String name, Exception excep) {
		System.out.println("Exception is " + excep.toString());
	}

	@Around("args(String)")
	public Object aroundMessage(ProceedingJoinPoint proceedingJoinPoint) {
		Object returnvalue = null;
		System.out.println("Message Around called");
		try {
			returnvalue = proceedingJoinPoint.proceed();
		} catch (Throwable e) {
		}
		return returnvalue;
	}

}
