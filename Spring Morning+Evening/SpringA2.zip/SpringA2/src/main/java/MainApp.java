import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.sau.service.ShapeService;

public class MainApp {

	public static void main(String[] args) {

		@SuppressWarnings("resource")
		ApplicationContext ctx = new AnnotationConfigApplicationContext(ConfigClass.class);
		ShapeService shapeService = ctx.getBean("shapeService", ShapeService.class);
		
		System.out.println("Setting Movie");
		shapeService.getMovie().setName("Avengers");
		System.out.println();
		System.out.println("Getting Movie");
		System.out.println("Name = "+shapeService.getMovie().getName());
		System.out.println();
		System.out.println("Caught Exception");

		shapeService.getSeries().setName("Exception");
		System.out.println();
	}
}
