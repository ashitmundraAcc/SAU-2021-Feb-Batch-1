package com.que1;

import java.util.Arrays;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean(name="rectangle")
    public Rectangle getRectangle() {
        return new Rectangle(100, 200);
    }

    @Bean(name="pointA")
    public Point getPointA() {
        return new Point(50, 50);
    }

    @Bean(name="pointB")
    public Point getPointB() {
        return new Point(150,50);
    }

    @Bean(name="pointC")
    public Point getPointC() {
        return new Point(150,250);
    }

    @Bean(name="pointD")
    public Point getPointD() {
        return new Point(50,250);
    }
    
}
