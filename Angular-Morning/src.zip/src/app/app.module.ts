import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';


import {FormsModule} from '@angular/forms';
import { LogdataComponent } from './logdata/logdata.component';
@NgModule({
  declarations: [
    AppComponent,
    LogdataComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
