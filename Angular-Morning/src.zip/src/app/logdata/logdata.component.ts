import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-logdata',
  templateUrl: './logdata.component.html',
  styleUrls: ['./logdata.component.css']
})
export class LogdataComponent implements OnInit {


  constructor() { }

  ngOnInit() {
  }

}
